## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/build-a-car-driving-game-from-scratch-using-javascript-video/9781838824648)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Build-a-Car-Driving-Game-from-Scratch-using-JavaScript
Code repository for Build a Car Driving Game from Scratch using JavaScript, Published by Packt
# Build a Car Driving Game from Scratch using JavaScript
This is the code repository for [Build a Car Driving Game from Scratch using JavaScript](https://www.packtpub.com/application-development/build-interactive-bird-flying-game-using-javascript-dom-video?utm_source=github&utm_medium=repository&utm_campaign=9781838823702), published by [Packt](https://www.packtpub.com/?utm_source=github). It contains all the supporting project files necessary to work through the video course from start to finish.
## About the Video Course
Using JUST JAVASCRIPT see how you can build a fully functional car racing game. Learn and practice applying JavaScript. Perfect for beginners to learn step by step to build interactive web applications. This course covers building a web site based car driving game, with all the source code and everything you need to build your own version. JavaScript core knowledge is a prerequisite for this course along with HTML and CSS. This course is designed for those who want to build interactive content using JavaScript and practice applying JavaScript in development.
The scope of the course is about applying JavaScript and seeing it in action. 
Course covers
Element Selection and manipulation via JavaScript
Updating element style properties to move elements on your webpage
Adding event listeners to create interactive content
Keyboard events used to move elements
Collision detection between two elements on the page
Using animation frame function in JavaScript
Creating elements dynamically
Applying logic for game functions
Step by step lessons - source code included
No libraries, no shortcuts just learning JavaScript making it DYNAMIC and INTERACTIVE web application. Step by step learning with all steps included. Beginner JavaScript knowledge is required as the course covers only JavaScript relevant to the building of the game. Also, HTML and CSS knowledge is essential as the scope of this course is all JavaScript-focused. Start building your own version of the game today! All the code and supporting files for this course are available at: https://github.com/PacktPublishing/Build-a-Car-Driving-Game-from-Scratch-using-JavaScript

<H2>What You Will Learn</H2>
<DIV class=book-info-will-learn-text>
<UL>
<LI>How to use JavaScript 
<LI>How to create elements dynamically 
<LI>Manipulate elements using JavaScript 
<LI>Explore the JavaScript Document Object Model </LI></UL></DIV>

## Instructions and Navigation
### Assumed Knowledge
To fully benefit from the coverage included in this course, you will need:<br/>
This course is for beginners to JavaScript curious about Document Object Model and JavaScript Methods. Anyone who wants to practice writing JavaScript and Web developers. Anyone who wants to learn to make a JavaScript game without any libraries.
### Technical Requirements
This course has the following software requirements:<br/>
    

## Related Products
* [Build a Dynamic and Interactive Element Catcher Game Using JavaScript [Video]](https://www.packtpub.com/application-development/build-interactive-bird-flying-game-using-javascript-dom-video?utm_source=github&utm_medium=repository&utm_campaign=9781838823702)

* [JavaScript - Card War Game Project [Video]](https://www.packtpub.com/application-development/build-interactive-bird-flying-game-using-javascript-dom-video?utm_source=github&utm_medium=repository&utm_campaign=9781838823702)

* [Build an Interactive Bird Flying Game Using JavaScript DOM [Video]](https://www.packtpub.com/application-development/build-interactive-bird-flying-game-using-javascript-dom-video?utm_source=github&utm_medium=repository&utm_campaign=9781838823702)

